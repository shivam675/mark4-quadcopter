Scripts that need to be available in TOOLS menu should be in this directory.
